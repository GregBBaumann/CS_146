// Here are the paths to the images
const fileLocations = {
   woofer: './img/woofer.jpg',
   pupper: './img/pupper.jpg',
   clouds: './img/clouds.jpg',
   snek: './img/snek.jpg'
};

/**
 * This function will get the values of the following elements:
 * 		formUsername, formCaption, formImg
 * Then, this will pass those values to the addNewPost function.
 * @param {Event} event the submit event of the #postForm form
 */
function handleFormSubmit(event) {
   // This next line prevents the reload of the form
   event.preventDefault();
   // Get values of inputs
   var formUsername = document.getElementById("formUsername").value;
   var formCaption = document.getElementById("formCaption").value;
   var formImg = document.getElementById("formImg").value;
   var imgLocation = fileLocations[formImg];
   // Pass values to addNewPost()
   addNewPost(formUsername,formCaption,imgLocation)
}

/**
 * This function create the following div and append it to the #postList element
	<div class="post">
		<span>{username}</span>
		<img src="{imgLocation}" alt="{caption}">
		<div class="postOverlay">
			{caption}
		</div>
	</div>
 * 
 * Also, add a mouseover and mouseleave events to the post div element
 * @param {String} username username of the post
 * @param {String} caption caption of the post
 * @param {String} imgLocation location of the post image
 */
function addNewPost(username, caption, imgLocation) {
   // Create the parent post div
   var div1 = document.createElement("div");
   var divatt = document.createAttribute("class");
   divatt.value = "post";
   div1.setAttributeNode(divatt);
   // Create a span for the user
   var span = document.createElement("span");
   span.innerHTML = username;
   // Create image element
   var img = document.createElement("img");
   var imgAtt1 = document.createAttribute("src");
   var imgAtt2 = document.createAttribute("alt");
   imgAtt1.value = imgLocation;
   imgAtt2.value = caption;
   img.setAttributeNode(imgAtt1);
   img.setAttributeNode(imgAtt2);
   // Create overlay element
   var div2 = document.createElement("div");
   var div2att = document.createAttribute("class");
   div2att.value = "postOverlay";
   div2.innerText = caption;
   // Add all child elements (order matters)
   div1.appendChild(span);
   div1.appendChild(img);
   div1.appendChild(div2);
   // Add event listeners to post
   div1.addEventListener("mouseover",function(){div2.style.opacity = '1';});
   div1.addEventListener("mouseleave",function(){div2.style.opacity = '0';});
   // Add post element to post list
   document.getElementById("postList").appendChild(div1);
}

window.onload = () => {
   // Once our window is loaded, we add the event listener for our post form
   postForm.addEventListener('submit', handleFormSubmit);
};